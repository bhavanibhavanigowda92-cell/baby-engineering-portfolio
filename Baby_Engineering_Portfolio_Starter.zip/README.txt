# Baby's Engineering Portfolio

A beginner-friendly personal portfolio website made with HTML and CSS in a light pink and white theme.

## Files
- `index.html` — page content
- `style.css` — layout, colours, and responsive design

## Before publishing
1. Open `index.html` and replace sample details with your real information.
2. Update project descriptions and clearly mark each project as planned, in progress, or completed.
3. Replace LinkedIn, GitHub, and email links with your own public professional links.
4. Do not publish private details such as home address, personal ID numbers, or passwords.

## Preview
Double-click `index.html` to open it in a browser.

## Publish with GitHub Pages
1. Create/sign in to GitHub and make a **public** repository named `portfolio` (or use `YOUR-USERNAME.github.io` for a user site).
2. Upload `index.html` and `style.css` to the repository's top level.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Choose the `main` branch and `/ (root)`, then Save.
6. Wait for the deployment to finish and open the URL shown in Pages settings. A project repository named `portfolio` usually publishes at `https://YOUR-USERNAME.github.io/portfolio/`; a user-site repository named `YOUR-USERNAME.github.io` publishes at `https://YOUR-USERNAME.github.io/`.

GitHub Pages websites are public. Check the content before publishing.
